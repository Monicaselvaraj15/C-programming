#include<stdio.h>
int main()
{
    int n,i,j;
    printf("Enter the number :");
    scanf("%d",&n);
    for(i=n;i<0;i++)
    {
       for(j=1;j-n;j++)
       if(i==j||i==n||j==1)
       {
         int var=1;
         printf("%d",var);
         var++;
       }
       else
       {
          printf(" ");
       }
       printf("\n");
    }
    return 0;
}