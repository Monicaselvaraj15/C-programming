/*Name:Monica.s
Date:28.08.2024
Description:Steganography
Input:./a.out -e beautiful.bmp secret.txt stego.bmp
Output:Selected encoding
       Read and validate encode arguments is a success
       Open files is a successfully
       width = 1024
       height = 768
       Check capacity is successfully
       Copied bmp header successfully
       Encoded magic string successfully
       Encoded secret file extn size successfully
       Encoded secret file extn successfully
       Encoded secret file size successfully
       Encoded secret file data successfully
       Copied remaining data successfully
       Completed encoding
Input:./a.out -d stego.bmp decode.txt
Output:Selected decoding
          Read and validate decode arguments is a success
           Open files is a successfully
          Decoded magic string Successfully
          Decoded file extension size Succesfully
          Decoded Secret File Extension Succesfully
          Decoded secret file size Successfully
          Decoded secret file data Succuessfully       
          Completed decoding
*/
#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"
#include "decode.h"
int main(int argc, char *argv[])
{
    if(check_operation_type(argv) == e_encode)
    {
        // read and validate
        EncodeInfo encInfo;
        printf("Selected Encoding\n");
        if(read_and_validate_encode_args(argv, &encInfo) == e_success)
        {
            printf("Read and validate enode argument is successfull\n");
            if(do_encoding(&encInfo) == e_success)
            {
                printf("Completed encoding\n");
            }
            else
            {
                printf("Failed to encode\n");
            }    
        }
        else
        {
            printf("Failed to read and validate encode argument..pass all required argument");
        }
    }
    else if(check_operation_type(argv) == e_decode)
    {
        printf("Selected decoding\n");

        // Declare structure variables
        DecodeInfo decInfo;
        if(read_and_validate_decode_args(argv, &decInfo) == d_success)
        {
            printf("Read and validate decode arguments is a success\n");
            if(do_decoding(&decInfo) == d_success)
            {
                printf("Completed decoding\n");
            }
            else
            {
                printf("Failed to decode\n");
            }
        }  
        else
        {
            printf("Read and validate decode arguments is a failure\n");
        }
        d_success;
    } 
    else
    {
        printf("Invalid option:\n");
        printf("Encoding:./a.out -e beautiful.bmp secret.text stego.bmp\n");
        printf("Decoding:./a.out -d stego.bmp output.text\n");
    }
}
OperationType check_operation_type(char *argv[])
{
    if (strcmp(argv[1], "-e") == 0)
    {
        return e_encode;
    }
    else if (strcmp(argv[1], "-d") == 0)
    {
        return e_decode;
    }
    else
    {
        e_unsupported;
    }
    return 0;
}

